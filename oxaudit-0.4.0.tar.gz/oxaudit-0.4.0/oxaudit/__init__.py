# oxaudit/__init__.py

from .scan import scan_contract
